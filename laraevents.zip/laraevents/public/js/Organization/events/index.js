$(document).on('click', '.confirm-submit', function(event){
    event.preventDefault();
    
    const confirmation = confirm('Tem certeza que seja excluir esse evento?');

    if ( confirmation) {
        const form = $(this).parent();
        form.trigger('submit');
    }
});