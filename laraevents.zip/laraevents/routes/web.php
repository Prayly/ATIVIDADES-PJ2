<?php

use App\Http\Controllers\Auth\loginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Participant\Dashboard\DashboardController as ParticipantDashboardController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Organization\{
    Dashboard\DashboardController as OrganizationDashboardController,
    Event\EventControllert
};
use App\Http\Middleware\Role;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['as' => 'auth.'], function(){
    Route::group(['middleware' => 'guest'], function(){
        Route::get('register', [RegisterController::class, 'create'])->name('auth.register.create');
        Route::post('register', [RegisterController::class, 'store'])->name('auth.register.store');
        Route::get('login',[loginController::class, 'create'])->name('auth.login.create');
        Route::post('login', [LogincController::class, 'store']) ->name('auth.login.store');
    });

Route::post('logout', [loginController::class, 'destroy'])->name('login.destroy')->middleware('auth');


});

Route::group(['middleware' => 'auth'], function() {

Route::get('participant/dashboard', [ParticipantDashboardController::class, 'index'])->name('participant.dashboard.index')->middleware('role:participant');

Route::group(['prefix' => 'organization', 'as' => 'organization.', 'middleware' => 'role:organization'], function(){
Route::get('dashboard', [OrganizationDashboardController::class, 'index'])->name('dashboard.index');

Route::get('events', [ EventController::class, 'index'])->name('.events.index');

Route::get('events/create', [ EventController::class, 'create'])->name('events.create');
Route::post('events', [EventController::class, 'store'])->name('events.store');
Route::get('events/{event}/edit', [EventController::class, 'edit'])->name('events.edit');
Route::put('events/{event}', [EventController::class, 'update'])
->name('events.update');
Route::delete('events/{events}', [EventController::class, 'destroy'])->name('events.destroy');

});

});