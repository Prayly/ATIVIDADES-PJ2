<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events_', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('speaker_name');
            $table->dateTime('stars_date');
            $table->dateTime('end_date');
            $table->text('target_audience');
            $table->integer9('participants_limit');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events_');
    }
}
