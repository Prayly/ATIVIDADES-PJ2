@extends('layouts.panel')
@section('title', 'Dashboard')
@section('content')
    Dashboard da Organizaçao
@endsection