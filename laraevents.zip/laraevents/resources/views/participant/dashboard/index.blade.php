@extends('layouts.panel')
@section('title', 'Dashboard')
@section('content')
    Dashboard do participante
@endsection