<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes as EloquentSoftDeletes;
use Illunate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;


class Event extends Model
{
    use HasFactory, EloquentSoftDeletes;

    protected $fillable = [
        'name',
        'speaker_name',
        'end_date',
        'target_audience',
        'participants_limit'
    ];

    public function setStartDateAttribute($value)
    {
        $this->attributes['start_date'] = Carbon::createFromFormat('d/m/Y', $value)
            ->format('Y-m-d H:i:s');
    }

    public function setEndDateAttribute($value)
    {
        $this->attributes['end_date'] = Carbon::createFromFormat('d/m/Y', $value)
            ->format('Y-m-d H:i:s');
    }

    public function getStartDateFormattedAttribute()
    {
        return Carbon::parse($this->start_date)->format('d/m/Y H:i');
    }

    public function getEndtDateFormattedAttribute()
    {
        return Carbon::parse($this->End_date)->format('d/m/Y H:i');
    }
}
